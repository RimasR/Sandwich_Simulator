#include <stdio.h>
#include "stack.h"

int main()
{
	Stack s=NULL;
	int err,elem;
	err=CreateStack(&s);
	PushElement(s,2);
	PushElement(s,3);
	PushElement(s, -39);
	PushElement(s,420);
	PushElement(s,69);
	printf("Your stack size is: ");
	printf("%d\n", SizeOfStack(s));
	printf("Your stack is: ");
	Print(s);
	printf("\n");
	printf("Your popped element is ");
	PopElement(s, &elem);
	printf("%d\n", elem);
	printf("Your popped element is ");
	PopElement(s, &elem);
	printf("%d\n", elem);
	if(CheckIfFull(s)==0)
		printf("Your stack is not full.\n");
	if(CheckIfEmpty(s)==1)
		printf("Your stack is empty.\n");
	FreeMemory(&s);
	Print(s);

	return 0;
}