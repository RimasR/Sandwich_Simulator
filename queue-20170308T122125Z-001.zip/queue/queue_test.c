#include "queue.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
   Queue *queue = CreateQueue();
   Queue *queue2 = CreateQueue(); 
   //Queue *queue = malloc(sizeof(Queue));
   char input = 0;
   while (input != 'q')
   {
       printf("e - prideti elementa, d - isimti, \
p - paziureti neisimant, q - iseiti\n");
       scanf("\n%c", &input);
       if (input == 'e')
       {
           printf("Iveskite skaiciu: ");
           int a;
           scanf("%d", &a);
           if (Enqueue(queue, a) != 0)
			   return 1;
       }
       else if (input == 'd')
       {
           int a;
           if (IsQueueEmpty(queue))
               printf("Eile tuscia\n");
           else
           {
               Dequeue(queue, &a);
               printf("%d\n", a);
           }
       }
       else if (input == 'p')
       {
           int a;
           if (IsQueueEmpty(queue))
               printf("Eile tuscia\n");
           else
           {
               QueuePeek(queue, &a);
               printf("%d\n", a);
           }
       }
   }
   DeleteQueue(queue);
}
